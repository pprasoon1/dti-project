import { SignedIn, SignedOut, SignIn, SignInButton, UserButton } from "@clerk/clerk-react";
import React from 'react'

export default function Login() {
  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh"}}>
      <SignIn afterSignInUrl="/" ></SignIn>
    </div>
  )
}
